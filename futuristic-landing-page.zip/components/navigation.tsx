"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, Zap } from "lucide-react"

const navLinks = [
  { label: "Fitur", href: "#features" },
  { label: "Alur Kerja", href: "#workflow" },
  { label: "Testimoni", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
]

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#001a12]/80 backdrop-blur-xl border-b border-[#00FF88]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="relative w-9 h-9">
              <div className="absolute inset-0 bg-gradient-to-br from-[#00FF88] to-[#00E0FF] rounded-xl blur-sm opacity-60" />
              <div className="relative w-full h-full bg-gradient-to-br from-[#00FF88] to-[#00FFA3] rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-[#001a12]" />
              </div>
            </div>
            <span className="text-foreground font-semibold text-lg tracking-tight">
              FlowSync
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-muted-foreground hover:text-[#00FF88] transition-colors text-sm"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-4">
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground hover:bg-[#00FF88]/10">
              Masuk
            </Button>
            <Button 
              size="sm" 
              className="bg-gradient-to-r from-[#00FF88] to-[#00FFA3] text-[#001a12] hover:opacity-90 shadow-lg shadow-[#00FF88]/25 font-medium"
            >
              Mulai Gratis
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-muted-foreground hover:text-foreground"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-[#00FF88]/10">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="text-muted-foreground hover:text-[#00FF88] transition-colors px-2 py-1"
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <div className="flex flex-col gap-2 pt-4 border-t border-[#00FF88]/10">
                <Button variant="ghost" className="justify-start text-muted-foreground hover:text-foreground hover:bg-[#00FF88]/10">
                  Masuk
                </Button>
                <Button className="bg-gradient-to-r from-[#00FF88] to-[#00FFA3] text-[#001a12] font-medium">
                  Mulai Gratis
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
