"use client"

import { motion } from "framer-motion"
import { useRef, useEffect, useState } from "react"
import { Layers, Target, Rocket, CheckCircle2 } from "lucide-react"

const nodes = [
  {
    id: 1,
    icon: Layers,
    title: "Kumpulkan",
    description: "Integrasi data dari berbagai sumber",
  },
  {
    id: 2,
    icon: Target,
    title: "Analisis",
    description: "AI memproses dan menganalisis",
  },
  {
    id: 3,
    icon: Rocket,
    title: "Automasi",
    description: "Eksekusi workflow otomatis",
  },
  {
    id: 4,
    icon: CheckCircle2,
    title: "Hasil",
    description: "Output dan insight real-time",
  },
]

export function WorkflowSection() {
  const svgRef = useRef<SVGSVGElement>(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })

  useEffect(() => {
    const updateDimensions = () => {
      if (svgRef.current) {
        const parent = svgRef.current.parentElement
        if (parent) {
          setDimensions({
            width: parent.offsetWidth,
            height: parent.offsetHeight,
          })
        }
      }
    }

    updateDimensions()
    window.addEventListener("resize", updateDimensions)
    return () => window.removeEventListener("resize", updateDimensions)
  }, [])

  return (
    <section id="workflow" className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00E0FF]/5 to-transparent pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16 lg:mb-24"
        >
          <span className="inline-block text-sm font-medium text-[#00E0FF] mb-4 tracking-wide uppercase">
            Alur Kerja
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Dibuat untuk Fokus Mendalam.
            <br />
            <span className="bg-gradient-to-r from-[#00FF88] via-[#00FFA3] to-[#00E0FF] bg-clip-text text-transparent">
              Dirancang untuk Kemajuan Nyata.
            </span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-muted-foreground text-pretty">
            Proses yang terintegrasi sempurna untuk hasil yang optimal.
          </p>
        </motion.div>

        {/* Workflow Diagram */}
        <div className="relative max-w-4xl mx-auto">
          {/* Connection Lines SVG */}
          <div className="absolute inset-0 pointer-events-none hidden md:block">
            <svg
              ref={svgRef}
              className="w-full h-full"
              viewBox={`0 0 ${dimensions.width || 800} ${dimensions.height || 200}`}
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#00FF88" stopOpacity="0.6" />
                  <stop offset="50%" stopColor="#00E0FF" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#00FF88" stopOpacity="0.6" />
                </linearGradient>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                  <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>
              
              {/* Animated connection path */}
              <motion.path
                d={`M ${dimensions.width * 0.125} 100 
                    C ${dimensions.width * 0.25} 50, ${dimensions.width * 0.35} 150, ${dimensions.width * 0.375} 100
                    C ${dimensions.width * 0.5} 50, ${dimensions.width * 0.6} 150, ${dimensions.width * 0.625} 100
                    C ${dimensions.width * 0.75} 50, ${dimensions.width * 0.85} 150, ${dimensions.width * 0.875} 100`}
                fill="none"
                stroke="url(#lineGradient)"
                strokeWidth="2"
                filter="url(#glow)"
                initial={{ pathLength: 0, opacity: 0 }}
                whileInView={{ pathLength: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 2, ease: "easeInOut" }}
              />

              {/* Animated dot along path */}
              <motion.circle
                r="6"
                fill="#00FF88"
                filter="url(#glow)"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <animateMotion
                  dur="4s"
                  repeatCount="indefinite"
                  path={`M ${dimensions.width * 0.125} 100 
                        C ${dimensions.width * 0.25} 50, ${dimensions.width * 0.35} 150, ${dimensions.width * 0.375} 100
                        C ${dimensions.width * 0.5} 50, ${dimensions.width * 0.6} 150, ${dimensions.width * 0.625} 100
                        C ${dimensions.width * 0.75} 50, ${dimensions.width * 0.85} 150, ${dimensions.width * 0.875} 100`}
                />
              </motion.circle>
            </svg>
          </div>

          {/* Nodes */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-4 relative z-10">
            {nodes.map((node, index) => (
              <motion.div
                key={node.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="flex flex-col items-center text-center group"
              >
                {/* Node Circle */}
                <div className="relative mb-4">
                  {/* Outer glow ring */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#00FF88] to-[#00E0FF] opacity-20 blur-xl group-hover:opacity-40 transition-opacity" />
                  
                  {/* Main circle */}
                  <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-[#00FF88]/20 to-[#00E0FF]/10 border border-[#00FF88]/30 flex items-center justify-center group-hover:border-[#00FF88]/60 transition-colors">
                    {/* Inner gradient circle */}
                    <div className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-[#00FF88]/30 to-[#00E0FF]/20 flex items-center justify-center group-hover:from-[#00FF88]/50 group-hover:to-[#00E0FF]/30 transition-colors">
                      <node.icon className="w-7 h-7 md:w-8 md:h-8 text-[#00FF88]" />
                    </div>
                  </div>

                  {/* Step number */}
                  <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-[#00FF88] text-[#001a12] text-sm font-bold flex items-center justify-center">
                    {node.id}
                  </div>
                </div>

                {/* Text */}
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {node.title}
                </h3>
                <p className="text-sm text-muted-foreground max-w-[140px]">
                  {node.description}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Mobile connecting lines */}
          <div className="flex md:hidden justify-center my-4">
            <div className="h-8 w-0.5 bg-gradient-to-b from-[#00FF88]/60 to-[#00E0FF]/60" />
          </div>
        </div>
      </div>
    </section>
  )
}
