"use client"

import { motion } from "framer-motion"
import { Star, Quote } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    quote: "FlowSync telah mengubah cara tim kami bekerja. Produktivitas meningkat 300% dalam bulan pertama. Luar biasa!",
    author: "Sarah Chen",
    role: "CTO",
    company: "TechVentures",
    avatar: "/avatars/sarah.jpg",
    rating: 5,
  },
  {
    quote: "Otomatisasi AI-nya sangat intuitif. Saya bisa fokus pada strategi sementara FlowSync menangani tugas rutin.",
    author: "Marcus Rodriguez",
    role: "VP of Engineering",
    company: "DataStream Inc",
    avatar: "/avatars/marcus.jpg",
    rating: 5,
  },
  {
    quote: "Keamanan enterprise-grade dengan kemudahan penggunaan consumer. Persis yang kami butuhkan untuk scaling.",
    author: "Emily Thompson",
    role: "Head of Operations",
    company: "FinSecure",
    avatar: "/avatars/emily.jpg",
    rating: 5,
  },
  {
    quote: "Integrasi dengan tools existing kami seamless. Tim onboarding dalam hitungan jam, bukan minggu.",
    author: "David Kim",
    role: "Product Manager",
    company: "CloudNine",
    avatar: "/avatars/david.jpg",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section id="testimonials" className="relative py-24 lg:py-32 overflow-hidden">
      {/* Glassmorphic background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00FF88]/3 to-transparent pointer-events-none" />
      
      {/* Green glow accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-[#00FF88]/5 rounded-full blur-[150px] pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-sm font-medium text-[#00FF88] mb-4 tracking-wide uppercase">
            Testimoni
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Dipercaya oleh Tim
            <br />
            <span className="relative inline-block">
              <span className="bg-gradient-to-r from-[#00FF88] via-[#00FFA3] to-[#00E0FF] bg-clip-text text-transparent">
                Inovatif di Seluruh Dunia
              </span>
              {/* Underline glow */}
              <span className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#00FF88]/0 via-[#00FF88]/50 to-[#00FF88]/0" />
            </span>
          </h2>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative"
            >
              {/* Glassmorphic Card */}
              <div className="relative h-full p-6 lg:p-8 rounded-2xl bg-[#0a1f18]/40 backdrop-blur-xl border border-[#00FF88]/10 hover:border-[#00FF88]/25 transition-all duration-300">
                {/* Depth effect - inner shadow/glow */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#00FF88]/5 via-transparent to-[#00E0FF]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                {/* Blur effect behind */}
                <div className="absolute -inset-px rounded-2xl bg-gradient-to-br from-[#00FF88]/10 to-[#00E0FF]/5 blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
                
                <div className="relative z-10">
                  {/* Quote icon */}
                  <Quote className="w-10 h-10 text-[#00FF88]/20 mb-4" />

                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star
                        key={i}
                        className="w-4 h-4 fill-[#00FF88] text-[#00FF88]"
                      />
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-foreground/90 leading-relaxed mb-6 text-pretty text-lg">
                    &ldquo;{testimonial.quote}&rdquo;
                  </p>

                  {/* Author */}
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      {/* Avatar glow ring */}
                      <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#00FF88] to-[#00E0FF] opacity-50 blur-sm" />
                      <div className="relative w-12 h-12 rounded-full bg-gradient-to-br from-[#00FF88]/30 to-[#00E0FF]/30 flex items-center justify-center border border-[#00FF88]/30">
                        <span className="text-foreground font-semibold text-lg">
                          {testimonial.author.charAt(0)}
                        </span>
                      </div>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">
                        {testimonial.author}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {testimonial.role}, {testimonial.company}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
