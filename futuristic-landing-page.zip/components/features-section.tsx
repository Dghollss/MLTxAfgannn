"use client"

import { motion } from "framer-motion"
import { 
  Zap, 
  Shield, 
  BarChart3, 
  Workflow
} from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "Otomatisasi Cerdas",
    description: "Otomatiskan tugas repetitif dengan AI yang belajar dari pola kerja Anda. Hemat waktu hingga 10x lebih efisien.",
    gradient: "from-[#00FF88] to-[#00FFA3]",
    glowColor: "#00FF88",
  },
  {
    icon: Shield,
    title: "Keamanan Enterprise",
    description: "Enkripsi end-to-end dengan sertifikasi SOC 2 dan GDPR. Data Anda aman di tangan terbaik.",
    gradient: "from-[#00E0FF] to-[#00FF88]",
    glowColor: "#00E0FF",
  },
  {
    icon: BarChart3,
    title: "Analitik Real-time",
    description: "Dashboard interaktif dengan insight AI yang membantu Anda membuat keputusan berbasis data.",
    gradient: "from-[#00FFA3] to-[#00E0FF]",
    glowColor: "#00FFA3",
  },
  {
    icon: Workflow,
    title: "Integrasi Seamless",
    description: "Hubungkan 200+ aplikasi favorit Anda dalam satu platform. Sync otomatis, tanpa coding.",
    gradient: "from-[#00FF88] to-[#00E0FF]",
    glowColor: "#00FF88",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
    },
  },
}

export function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 lg:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00FF88]/5 to-transparent pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16 lg:mb-20"
        >
          <span className="inline-block text-sm font-medium text-[#00FF88] mb-4 tracking-wide uppercase">
            Fitur Unggulan
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Semua yang Anda Butuhkan
            <br />
            <span className="bg-gradient-to-r from-[#00FF88] via-[#00FFA3] to-[#00E0FF] bg-clip-text text-transparent">
              dalam Satu Platform
            </span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-muted-foreground text-pretty">
            Fitur-fitur powerful yang dirancang untuk meningkatkan produktivitas 
            dan mempercepat pertumbuhan bisnis Anda.
          </p>
        </motion.div>

        {/* Features Grid - 4 Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="group relative"
            >
              {/* Card */}
              <div className="relative h-full p-8 rounded-2xl bg-[#0a1f18]/60 backdrop-blur-sm border border-[#00FF88]/10 hover:border-[#00FF88]/30 transition-all duration-500 overflow-hidden">
                {/* Hover glow effect */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    background: `radial-gradient(600px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), ${feature.glowColor}15, transparent 40%)`,
                  }}
                />
                
                {/* Animated border glow */}
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div 
                    className="absolute inset-[-1px] rounded-2xl"
                    style={{
                      background: `linear-gradient(135deg, ${feature.glowColor}40, transparent, ${feature.glowColor}20)`,
                    }}
                  />
                </div>
                
                <div className="relative z-10">
                  {/* Icon */}
                  <div 
                    className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} p-0.5 mb-6 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <div className="w-full h-full rounded-[10px] bg-[#001a12] flex items-center justify-center">
                      <feature.icon className="w-7 h-7 text-[#00FF88]" />
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-xl lg:text-2xl font-semibold text-foreground mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed text-base">
                    {feature.description}
                  </p>

                  {/* Pulse effect on hover */}
                  <div 
                    className="absolute top-8 left-8 w-14 h-14 rounded-xl opacity-0 group-hover:opacity-100 group-hover:animate-ping pointer-events-none"
                    style={{ backgroundColor: `${feature.glowColor}20` }}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
