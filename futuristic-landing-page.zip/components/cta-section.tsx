"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

export function CTASection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#00FF88]/5 via-transparent to-transparent" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#00FF88]/10 rounded-full blur-[150px]" />
      <div className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-[#00E0FF]/8 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00FF88]/10 border border-[#00FF88]/30 mb-8">
            <Sparkles className="w-4 h-4 text-[#00FF88]" />
            <span className="text-sm text-[#00FF88] font-medium">
              Penawaran Terbatas
            </span>
          </div>

          {/* Heading */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Siap Meningkatkan
            <br />
            <span className="bg-gradient-to-r from-[#00FF88] via-[#00FFA3] to-[#00E0FF] bg-clip-text text-transparent">
              Produktivitas Anda?
            </span>
          </h2>

          {/* Description */}
          <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto text-pretty">
            Bergabung dengan ribuan perusahaan yang sudah menggunakan FlowSync untuk 
            mengotomatisasi alur kerja mereka. Mulai trial gratis Anda hari ini.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <Button
              size="lg"
              className="relative overflow-hidden bg-gradient-to-r from-[#00FF88] to-[#00FFA3] text-[#001a12] hover:opacity-90 shadow-lg shadow-[#00FF88]/30 px-8 h-14 text-base font-semibold group"
            >
              <span className="relative z-10 flex items-center">
                Mulai Trial Gratis
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </span>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-[#00FF88]/40 text-foreground hover:bg-[#00FF88]/10 hover:border-[#00FF88]/60 px-8 h-14 text-base bg-transparent"
            >
              Jadwalkan Demo
            </Button>
          </div>

          {/* Trust indicators */}
          <p className="text-sm text-muted-foreground">
            Tanpa kartu kredit. Trial 14 hari gratis. Batalkan kapan saja.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
