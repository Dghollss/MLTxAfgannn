"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { ChevronDown, HelpCircle } from "lucide-react"

const faqs = [
  {
    question: "Bagaimana cara memulai dengan FlowSync?",
    answer: "Cukup daftar akun gratis, hubungkan aplikasi yang Anda gunakan, dan AI kami akan mulai menganalisis alur kerja Anda. Dalam hitungan menit, Anda sudah bisa melihat rekomendasi otomatisasi pertama.",
  },
  {
    question: "Apakah data saya aman dengan FlowSync?",
    answer: "Keamanan adalah prioritas utama kami. FlowSync menggunakan enkripsi end-to-end, sertifikasi SOC 2 Type II, dan mematuhi standar GDPR. Data Anda tidak pernah dibagikan kepada pihak ketiga.",
  },
  {
    question: "Aplikasi apa saja yang bisa diintegrasikan?",
    answer: "FlowSync mendukung 200+ integrasi populer termasuk Slack, Google Workspace, Microsoft 365, Notion, Asana, Jira, Salesforce, HubSpot, dan masih banyak lagi. Kami terus menambah integrasi baru setiap bulan.",
  },
  {
    question: "Berapa biaya berlangganan FlowSync?",
    answer: "Kami menawarkan paket gratis untuk tim kecil hingga 3 pengguna. Paket Pro mulai dari $12/pengguna/bulan dengan fitur lengkap. Enterprise plan tersedia dengan harga khusus dan dukungan dedicated.",
  },
  {
    question: "Apakah ada masa trial untuk paket berbayar?",
    answer: "Ya! Semua paket berbayar memiliki trial gratis 14 hari tanpa perlu kartu kredit. Anda bisa mengeksplorasi semua fitur premium sebelum memutuskan berlangganan.",
  },
  {
    question: "Bagaimana cara mendapatkan dukungan teknis?",
    answer: "Tim support kami tersedia 24/7 melalui live chat dan email. Pengguna Enterprise mendapatkan dedicated account manager dan prioritas response time di bawah 1 jam.",
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section id="faq" className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00E0FF]/3 to-transparent pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left - 3D Question Mark / Abstract Object */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative flex items-center justify-center lg:sticky lg:top-32"
          >
            {/* Glowing 3D Question Mark */}
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              {/* Outer glow rings */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#00FF88]/20 to-[#00E0FF]/20 blur-3xl animate-pulse" />
              <div className="absolute inset-8 rounded-full bg-gradient-to-r from-[#00E0FF]/15 to-[#00FF88]/15 blur-2xl animate-pulse delay-500" />
              
              {/* Main container */}
              <div className="absolute inset-0 flex items-center justify-center">
                {/* Rotating border effect */}
                <div className="absolute w-48 h-48 md:w-56 md:h-56 rounded-full border border-[#00FF88]/20 animate-spin" style={{ animationDuration: '20s' }} />
                <div className="absolute w-40 h-40 md:w-48 md:h-48 rounded-full border border-[#00E0FF]/20 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
                
                {/* Glowing question mark */}
                <div className="relative">
                  <HelpCircle className="w-24 h-24 md:w-32 md:h-32 text-[#00FF88]" strokeWidth={1} />
                  {/* Inner glow */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <HelpCircle className="w-24 h-24 md:w-32 md:h-32 text-[#00FF88] blur-lg opacity-50" strokeWidth={1} />
                  </div>
                </div>
              </div>

              {/* Floating particles */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-2 h-2 rounded-full bg-[#00FF88]"
                  style={{
                    top: `${20 + Math.random() * 60}%`,
                    left: `${20 + Math.random() * 60}%`,
                  }}
                  animate={{
                    y: [-10, 10, -10],
                    opacity: [0.3, 0.8, 0.3],
                  }}
                  transition={{
                    duration: 2 + Math.random() * 2,
                    repeat: Infinity,
                    delay: Math.random() * 2,
                  }}
                />
              ))}
            </div>

            {/* Section Title for mobile (hidden on lg) */}
            <div className="absolute -top-16 left-0 right-0 text-center lg:hidden">
              <span className="inline-block text-sm font-medium text-[#00E0FF] mb-4 tracking-wide uppercase">
                FAQ
              </span>
              <h2 className="text-3xl font-bold text-foreground">
                Pertanyaan Umum
              </h2>
            </div>
          </motion.div>

          {/* Right - FAQ Accordion */}
          <div>
            {/* Section Title for desktop */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="hidden lg:block mb-10"
            >
              <span className="inline-block text-sm font-medium text-[#00E0FF] mb-4 tracking-wide uppercase">
                FAQ
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4 text-balance">
                Pertanyaan yang Sering
                <br />
                <span className="bg-gradient-to-r from-[#00FF88] to-[#00E0FF] bg-clip-text text-transparent">
                  Ditanyakan
                </span>
              </h2>
            </motion.div>

            {/* Accordion Items */}
            <div className="space-y-4 mt-20 lg:mt-0">
              {faqs.map((faq, index) => (
                <motion.div
                  key={faq.question}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="group"
                >
                  <div
                    className={`relative rounded-xl overflow-hidden transition-all duration-300 ${
                      openIndex === index 
                        ? 'bg-[#0a1f18]/60 border-[#00FF88]/30' 
                        : 'bg-[#0a1f18]/30 border-[#00FF88]/10 hover:border-[#00FF88]/20'
                    } border`}
                  >
                    {/* Gradient border effect on hover/active */}
                    <div className={`absolute inset-0 bg-gradient-to-r from-[#00FF88]/10 to-[#00E0FF]/10 opacity-0 ${
                      openIndex === index ? 'opacity-100' : 'group-hover:opacity-50'
                    } transition-opacity`} />
                    
                    {/* Question button */}
                    <button
                      onClick={() => setOpenIndex(openIndex === index ? null : index)}
                      className="relative w-full px-6 py-5 flex items-center justify-between text-left"
                    >
                      <span className="font-medium text-foreground pr-8">
                        {faq.question}
                      </span>
                      <ChevronDown 
                        className={`w-5 h-5 text-[#00FF88] transition-transform duration-300 ${
                          openIndex === index ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {/* Answer */}
                    <motion.div
                      initial={false}
                      animate={{
                        height: openIndex === index ? 'auto' : 0,
                        opacity: openIndex === index ? 1 : 0,
                      }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <div className="relative px-6 pb-5 text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
