"use client"

import { useEffect, useRef } from "react"

interface Particle {
  x: number
  y: number
  size: number
  speedY: number
  opacity: number
  hue: number
  drift: number
  driftSpeed: number
}

export function EnergyWaveBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let time = 0
    let particles: Particle[] = []

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      initParticles()
    }

    const initParticles = () => {
      particles = []
      const particleCount = Math.floor((canvas.width * canvas.height) / 8000)
      
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speedY: Math.random() * 1.5 + 0.5,
          opacity: Math.random() * 0.5 + 0.2,
          hue: Math.random() > 0.5 ? 145 : 180, // Green or cyan
          drift: Math.random() * Math.PI * 2,
          driftSpeed: Math.random() * 0.02 + 0.01,
        })
      }
    }

    const drawVerticalEnergyBeam = () => {
      const centerX = canvas.width / 2
      const beamWidth = 300
      
      // Main energy beam core - brightest center
      const coreGradient = ctx.createLinearGradient(
        centerX - beamWidth / 4, 0,
        centerX + beamWidth / 4, 0
      )
      coreGradient.addColorStop(0, "rgba(0, 255, 136, 0)")
      coreGradient.addColorStop(0.3, "rgba(0, 255, 136, 0.15)")
      coreGradient.addColorStop(0.5, "rgba(0, 255, 136, 0.4)")
      coreGradient.addColorStop(0.7, "rgba(0, 255, 136, 0.15)")
      coreGradient.addColorStop(1, "rgba(0, 255, 136, 0)")
      
      ctx.fillStyle = coreGradient
      ctx.fillRect(centerX - beamWidth / 2, 0, beamWidth, canvas.height)

      // Outer glow layers
      for (let i = 0; i < 3; i++) {
        const layerWidth = beamWidth * (1.5 + i * 0.5)
        const opacity = 0.08 - i * 0.02
        
        const glowGradient = ctx.createLinearGradient(
          centerX - layerWidth / 2, 0,
          centerX + layerWidth / 2, 0
        )
        glowGradient.addColorStop(0, "rgba(0, 224, 255, 0)")
        glowGradient.addColorStop(0.3, `rgba(0, 255, 136, ${opacity})`)
        glowGradient.addColorStop(0.5, `rgba(0, 255, 163, ${opacity * 1.5})`)
        glowGradient.addColorStop(0.7, `rgba(0, 255, 136, ${opacity})`)
        glowGradient.addColorStop(1, "rgba(0, 224, 255, 0)")
        
        ctx.fillStyle = glowGradient
        ctx.fillRect(centerX - layerWidth / 2, 0, layerWidth, canvas.height)
      }
    }

    const drawFlowingEnergyStreams = () => {
      const centerX = canvas.width / 2
      const streamCount = 8
      
      for (let i = 0; i < streamCount; i++) {
        const offset = (i - streamCount / 2) * 40
        const phase = time * 0.5 + i * 0.5
        
        ctx.beginPath()
        ctx.strokeStyle = i % 2 === 0 
          ? `rgba(0, 255, 136, ${0.3 - Math.abs(offset) * 0.002})` 
          : `rgba(0, 224, 255, ${0.25 - Math.abs(offset) * 0.002})`
        ctx.lineWidth = 2
        ctx.shadowBlur = 20
        ctx.shadowColor = i % 2 === 0 ? "#00FF88" : "#00E0FF"
        
        for (let y = 0; y < canvas.height; y += 3) {
          const waveX = Math.sin(y * 0.01 + phase) * 30 + 
                        Math.sin(y * 0.02 + phase * 1.5) * 15
          const x = centerX + offset + waveX
          
          if (y === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        }
        ctx.stroke()
      }
      
      ctx.shadowBlur = 0
    }

    const drawPlasmaTendrils = () => {
      const centerX = canvas.width / 2
      const tendrilCount = 12
      
      for (let i = 0; i < tendrilCount; i++) {
        const baseOffset = (Math.random() - 0.5) * 200
        const yStart = (time * 100 + i * (canvas.height / tendrilCount)) % canvas.height
        
        ctx.beginPath()
        const gradient = ctx.createLinearGradient(centerX, yStart, centerX, yStart + 200)
        gradient.addColorStop(0, "rgba(0, 255, 136, 0.6)")
        gradient.addColorStop(0.5, "rgba(0, 224, 255, 0.3)")
        gradient.addColorStop(1, "rgba(0, 255, 136, 0)")
        
        ctx.strokeStyle = gradient
        ctx.lineWidth = 1.5
        ctx.shadowBlur = 15
        ctx.shadowColor = "#00FF88"
        
        for (let j = 0; j < 200; j += 4) {
          const noise = Math.sin(j * 0.05 + time * 2 + i) * 20
          const x = centerX + baseOffset + noise
          const y = yStart + j
          
          if (j === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        }
        ctx.stroke()
      }
      
      ctx.shadowBlur = 0
    }

    const drawParticles = () => {
      particles.forEach((particle, index) => {
        // Update particle position
        particle.y -= particle.speedY
        particle.drift += particle.driftSpeed
        particle.x += Math.sin(particle.drift) * 0.5
        
        // Reset particle if it goes off screen
        if (particle.y < -10) {
          particle.y = canvas.height + 10
          particle.x = Math.random() * canvas.width
        }
        
        // Increase opacity near center beam
        const centerX = canvas.width / 2
        const distFromCenter = Math.abs(particle.x - centerX)
        const centerBoost = Math.max(0, 1 - distFromCenter / 300) * 0.5
        
        // Draw particle glow
        const gradient = ctx.createRadialGradient(
          particle.x, particle.y, 0,
          particle.x, particle.y, particle.size * 4
        )
        
        const color = particle.hue === 145 ? "0, 255, 136" : "0, 224, 255"
        gradient.addColorStop(0, `rgba(${color}, ${(particle.opacity + centerBoost) * 0.8})`)
        gradient.addColorStop(0.5, `rgba(${color}, ${(particle.opacity + centerBoost) * 0.3})`)
        gradient.addColorStop(1, `rgba(${color}, 0)`)
        
        ctx.beginPath()
        ctx.fillStyle = gradient
        ctx.arc(particle.x, particle.y, particle.size * 4, 0, Math.PI * 2)
        ctx.fill()
        
        // Draw particle core
        ctx.beginPath()
        ctx.fillStyle = `rgba(${color}, ${particle.opacity + centerBoost})`
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    const drawAmbientGlow = () => {
      // Bottom ambient glow
      const bottomGlow = ctx.createLinearGradient(0, canvas.height, 0, canvas.height - 400)
      bottomGlow.addColorStop(0, "rgba(0, 26, 18, 0.8)")
      bottomGlow.addColorStop(0.5, "rgba(0, 255, 136, 0.05)")
      bottomGlow.addColorStop(1, "rgba(0, 0, 0, 0)")
      
      ctx.fillStyle = bottomGlow
      ctx.fillRect(0, canvas.height - 400, canvas.width, 400)
      
      // Top ambient fade
      const topGlow = ctx.createLinearGradient(0, 0, 0, 300)
      topGlow.addColorStop(0, "rgba(0, 26, 18, 0.6)")
      topGlow.addColorStop(1, "rgba(0, 0, 0, 0)")
      
      ctx.fillStyle = topGlow
      ctx.fillRect(0, 0, canvas.width, 300)
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      // Draw layers from back to front
      drawAmbientGlow()
      drawVerticalEnergyBeam()
      drawFlowingEnergyStreams()
      drawPlasmaTendrils()
      drawParticles()

      time += 0.016
      animationFrameId = requestAnimationFrame(animate)
    }

    resize()
    window.addEventListener("resize", resize)
    animate()

    return () => {
      window.removeEventListener("resize", resize)
      cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ background: "linear-gradient(180deg, #001a12 0%, #000a08 50%, #001a12 100%)" }}
    />
  )
}
