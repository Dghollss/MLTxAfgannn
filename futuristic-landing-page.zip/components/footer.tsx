import { Github, Twitter, Linkedin, Zap } from "lucide-react"

const footerLinks = {
  product: [
    { label: "Fitur", href: "#features" },
    { label: "Alur Kerja", href: "#workflow" },
    { label: "Integrasi", href: "#" },
    { label: "Changelog", href: "#" },
  ],
  company: [
    { label: "Tentang", href: "#" },
    { label: "Blog", href: "#" },
    { label: "Karir", href: "#" },
    { label: "Kontak", href: "#" },
  ],
  resources: [
    { label: "Dokumentasi", href: "#" },
    { label: "API Reference", href: "#" },
    { label: "Tutorial", href: "#" },
    { label: "Support", href: "#" },
  ],
  legal: [
    { label: "Privasi", href: "#" },
    { label: "Syarat", href: "#" },
    { label: "Keamanan", href: "#" },
  ],
}

const socialLinks = [
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Github, href: "#", label: "GitHub" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
]

export function Footer() {
  return (
    <footer className="relative border-t border-[#00FF88]/10 bg-[#0a1f18]/30">
      {/* Gradient line at top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00FF88]/50 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-gradient-to-br from-[#00FF88] to-[#00E0FF] rounded-xl blur-sm opacity-60" />
                <div className="relative w-full h-full bg-gradient-to-br from-[#00FF88] to-[#00FFA3] rounded-xl flex items-center justify-center">
                  <Zap className="w-5 h-5 text-[#001a12]" />
                </div>
              </div>
              <span className="text-foreground font-semibold text-xl">
                FlowSync
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-6 max-w-xs leading-relaxed">
              Transformasi alur kerja Anda dengan otomatisasi AI yang cerdas. 
              Dibuat untuk tim yang menuntut keunggulan.
            </p>
            <div className="flex items-center gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="group w-10 h-10 rounded-lg bg-[#00FF88]/5 border border-[#00FF88]/10 flex items-center justify-center text-muted-foreground hover:text-[#00FF88] hover:border-[#00FF88]/30 hover:bg-[#00FF88]/10 transition-all"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4" />
                  {/* Glow on hover */}
                  <span className="absolute inset-0 rounded-lg bg-[#00FF88]/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity -z-10" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Produk</h4>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-[#00FF88] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Perusahaan</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-[#00FF88] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Resources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-[#00FF88] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-[#00FF88] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-[#00FF88]/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            2026 FlowSync. Hak cipta dilindungi.
          </p>
          <p className="text-sm text-muted-foreground">
            Dibuat dengan presisi untuk masa depan kerja.
          </p>
        </div>
      </div>
    </footer>
  )
}
