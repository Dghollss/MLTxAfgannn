"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, Play, Zap, Shield, TrendingUp } from "lucide-react"
import { motion } from "framer-motion"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Additional glow effects */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#00FF88]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-[400px] h-[400px] bg-[#00E0FF]/8 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00FF88]/10 border border-[#00FF88]/30 mb-8"
            >
              <Sparkles className="w-4 h-4 text-[#00FF88]" />
              <span className="text-sm text-[#00FF88] font-medium">
                Memperkenalkan FlowSync 2.0
              </span>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground mb-6"
            >
              <span className="text-balance">
                Alur Kerja Terpadu.
                <br />
                <span className="relative inline-block mt-2">
                  <span className="bg-gradient-to-r from-[#00FF88] via-[#00FFA3] to-[#00E0FF] bg-clip-text text-transparent">
                    Fokus Tanpa Batas.
                  </span>
                  <span className="absolute -inset-2 bg-gradient-to-r from-[#00FF88]/20 via-[#00FFA3]/15 to-[#00E0FF]/20 blur-2xl -z-10" />
                </span>
              </span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="max-w-xl mx-auto lg:mx-0 text-lg sm:text-xl text-muted-foreground mb-10 text-pretty leading-relaxed"
            >
              Tingkatkan produktivitas tim Anda dengan otomatisasi cerdas berbasis AI. 
              Satukan semua alat kerja dalam satu platform yang intuitif dan powerful.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center lg:items-start justify-center lg:justify-start gap-4 mb-12"
            >
              <Button 
                size="lg" 
                className="relative overflow-hidden bg-gradient-to-r from-[#00FF88] to-[#00FFA3] text-[#001a12] hover:opacity-90 shadow-lg shadow-[#00FF88]/30 px-8 h-14 text-base font-semibold group"
              >
                <span className="relative z-10 flex items-center">
                  Mulai Gratis Sekarang
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="absolute inset-0 bg-gradient-to-r from-[#00FFA3] to-[#00FF88] opacity-0 group-hover:opacity-100 transition-opacity" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-[#00FF88]/40 text-foreground hover:bg-[#00FF88]/10 hover:border-[#00FF88]/60 px-8 h-14 text-base group bg-transparent"
              >
                <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform text-[#00FF88]" />
                Tonton Demo
              </Button>
            </motion.div>

            {/* Trust Indicators */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-sm text-muted-foreground"
            >
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#00FF88]" />
                <span>SOC 2 Certified</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#00E0FF]" />
                <span>99.99% Uptime</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#00FFA3]" />
                <span>10K+ Users</span>
              </div>
            </motion.div>
          </div>

          {/* Right Content - Futuristic Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, x: 50, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative"
          >
            {/* Main Dashboard Card */}
            <div className="relative bg-[#0a1f18]/80 backdrop-blur-xl border border-[#00FF88]/20 rounded-2xl p-6 shadow-2xl shadow-[#00FF88]/10">
              {/* Glow effect behind card */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[#00FF88]/20 via-[#00E0FF]/10 to-[#00FF88]/20 rounded-2xl blur-xl -z-10" />
              
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00FF88] to-[#00E0FF] flex items-center justify-center">
                    <Zap className="w-5 h-5 text-[#001a12]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Dashboard AI</h3>
                    <p className="text-xs text-muted-foreground">Real-time analytics</p>
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-[#00FF88]/60" />
                  <div className="w-3 h-3 rounded-full bg-[#00E0FF]/60" />
                  <div className="w-3 h-3 rounded-full bg-muted" />
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                {[
                  { label: "Tasks Completed", value: "1,247", change: "+12%" },
                  { label: "Time Saved", value: "48h", change: "+23%" },
                  { label: "Efficiency", value: "94%", change: "+8%" },
                ].map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.5 + i * 0.1 }}
                    className="bg-[#001a12]/50 rounded-xl p-4 border border-[#00FF88]/10"
                  >
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <span className="text-xs text-[#00FF88]">{stat.change}</span>
                  </motion.div>
                ))}
              </div>

              {/* Activity Graph Placeholder */}
              <div className="h-32 bg-[#001a12]/30 rounded-xl border border-[#00FF88]/10 p-4 relative overflow-hidden">
                <div className="flex items-end justify-between h-full gap-2">
                  {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 88].map((height, i) => (
                    <motion.div
                      key={i}
                      initial={{ height: 0 }}
                      animate={{ height: `${height}%` }}
                      transition={{ duration: 0.5, delay: 0.6 + i * 0.05 }}
                      className="flex-1 rounded-t bg-gradient-to-t from-[#00FF88]/60 to-[#00E0FF]/40"
                    />
                  ))}
                </div>
                <div className="absolute bottom-4 left-4 text-xs text-muted-foreground">Weekly Activity</div>
              </div>
            </div>

            {/* Floating Cards */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="absolute -left-8 top-1/4 bg-[#0a1f18]/90 backdrop-blur-lg border border-[#00FF88]/20 rounded-xl p-4 shadow-lg"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#00FF88]/20 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-[#00FF88]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Productivity</p>
                  <p className="text-xs text-[#00FF88]">+27% this week</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.9 }}
              className="absolute -right-4 bottom-1/4 bg-[#0a1f18]/90 backdrop-blur-lg border border-[#00E0FF]/20 rounded-xl p-4 shadow-lg"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#00E0FF]/20 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-[#00E0FF]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">AI Suggestions</p>
                  <p className="text-xs text-[#00E0FF]">12 new insights</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
